# SDC

- [Self-Driving Cars Lectures by Lex Fridman](https://www.youtube.com/playlist?list=PLrAXtmErZgOeY0lkVCIVafdGFOTi45amq)

## [waymo-open-dataset](https://github.com/waymo-research/waymo-open-dataset)

Waymo Open Dataset https://www.waymo.com/open

### MIT 6.S094: Deep Learning for Self-Driving Cars

- [DeepTraffic](https://selfdrivingcars.mit.edu/deeptraffic/)
