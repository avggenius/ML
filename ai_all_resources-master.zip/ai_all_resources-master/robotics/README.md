### Robotics

## A curated collection of places where you can learn robotics, algorithms, and other useful tools for aspiring robotics software engineers.

https://github.com/soaicbe/robotics-coursework
